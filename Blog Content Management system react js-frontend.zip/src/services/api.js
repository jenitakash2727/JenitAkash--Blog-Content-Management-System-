import axios from 'axios';

const API_URL = 'http://127.0.0.1:8000/api';

const api = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

export const postService = {
    // Get all posts
    getAllPosts: () => api.get('/posts/'),
    
    // Get single post
    getPostById: (id) => api.get(`/posts/${id}/`),
    
    // Create new post
    createPost: (postData) => api.post('/posts/', postData),
    
    // Update post
    updatePost: (id, postData) => api.put(`/posts/${id}/`, postData),
    
    // Delete post
    deletePost: (id) => api.delete(`/posts/${id}/`),
    
    // Search posts
    searchPosts: (query) => api.get(`/posts/?search=${query}`),
    
    // Filter posts
    filterPosts: (filters) => api.get('/posts/', { params: filters }),
};