import React from 'react';
import PostList from '../components/PostList';

function Home() {
    return (
        <div>
            <div style={styles.hero}>
                <h1 style={styles.heroTitle}>Welcome to Blog CMS</h1>
                <p style={styles.heroText}>Create, manage, and share your blog posts easily</p>
            </div>
            <PostList />
        </div>
    );
}

const styles = {
    hero: {
        backgroundColor: '#007bff',
        color: 'white',
        padding: '40px 20px',
        textAlign: 'center',
        marginBottom: '40px'
    },
    heroTitle: {
        fontSize: '36px',
        marginBottom: '10px'
    },
    heroText: {
        fontSize: '18px',
        opacity: '0.9'
    }
};

export default Home;