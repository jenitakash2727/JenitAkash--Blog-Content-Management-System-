import React, { useState } from 'react';
import { postService } from '../services/api';
import { useNavigate } from 'react-router-dom';

function CreatePost() {
    const navigate = useNavigate();
    const [title, setTitle] = useState('');
    const [author, setAuthor] = useState('');
    const [content, setContent] = useState('');
    const [category, setCategory] = useState('Technology');

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        const postData = {
            title: title,
            content: content,
            author: author,
            category: category,
            status: 'Draft'
        };

        try {
            await postService.createPost(postData);
            alert('Post created successfully!');
            navigate('/');
        } catch (error) {
            console.error('Error:', error);
            alert('Error creating post. Check console.');
        }
    };

    return (
        <div style={styles.container}>
            <h2 style={styles.heading}>Create New Post</h2>
            
            <form onSubmit={handleSubmit} style={styles.form}>
                {/* Title Field */}
                <div style={styles.formGroup}>
                    <label style={styles.label}>Title *</label>
                    <input 
                        type="text" 
                        style={styles.input}
                        value={title} 
                        onChange={(e) => setTitle(e.target.value)} 
                        required 
                        placeholder="Enter post title"
                    />
                </div>
                
                {/* Author Field */}
                <div style={styles.formGroup}>
                    <label style={styles.label}>Author *</label>
                    <input 
                        type="text" 
                        style={styles.input}
                        value={author} 
                        onChange={(e) => setAuthor(e.target.value)} 
                        required 
                        placeholder="Enter author name"
                    />
                </div>
                
                {/* Category Field */}
                <div style={styles.formGroup}>
                    <label style={styles.label}>Category</label>
                    <select 
                        style={styles.input}
                        value={category} 
                        onChange={(e) => setCategory(e.target.value)}
                    >
                        <option value="Technology">Technology</option>
                        <option value="Lifestyle">Lifestyle</option>
                        <option value="Travel">Travel</option>
                        <option value="Food">Food</option>
                        <option value="Business">Business</option>
                    </select>
                </div>
                
                {/* Content Field */}
                <div style={styles.formGroup}>
                    <label style={styles.label}>Content *</label>
                    <textarea 
                        style={{...styles.input, height: '150px'}}
                        value={content} 
                        onChange={(e) => setContent(e.target.value)} 
                        required 
                        placeholder="Write your post content here..."
                    />
                </div>
                
                {/* Buttons */}
                <div style={styles.buttonGroup}>
                    <button type="submit" style={styles.primaryButton}>
                        Create Post
                    </button>
                    <button 
                        type="button" 
                        style={styles.secondaryButton}
                        onClick={() => navigate('/')}
                    >
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    );
}

// Inline styles
const styles = {
    container: {
        maxWidth: '600px',
        margin: '40px auto',
        padding: '20px',
        backgroundColor: '#f8f9fa',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
    },
    heading: {
        color: '#333',
        marginBottom: '30px',
        textAlign: 'center'
    },
    form: {
        display: 'flex',
        flexDirection: 'column'
    },
    formGroup: {
        marginBottom: '20px'
    },
    label: {
        display: 'block',
        marginBottom: '8px',
        fontWeight: 'bold',
        color: '#555'
    },
    input: {
        width: '100%',
        padding: '10px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        fontSize: '16px',
        boxSizing: 'border-box'
    },
    buttonGroup: {
        display: 'flex',
        gap: '10px',
        marginTop: '20px'
    },
    primaryButton: {
        padding: '10px 20px',
        backgroundColor: '#007bff',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontSize: '16px',
        flex: 1
    },
    secondaryButton: {
        padding: '10px 20px',
        backgroundColor: '#6c757d',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontSize: '16px',
        flex: 1
    }
};

export default CreatePost;