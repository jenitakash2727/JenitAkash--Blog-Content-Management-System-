import React from 'react';
import { Link } from 'react-router-dom';

function Header() {
    return (
        <div style={styles.navbar}>
            <div style={styles.container}>
                <Link to="/" style={styles.brand}>Blog CMS</Link>
                <div style={styles.navLinks}>
                    <Link to="/" style={styles.navLink}>Home</Link>
                    <Link to="/create" style={styles.navLink}>Create Post</Link>
                </div>
            </div>
        </div>
    );
}

const styles = {
    navbar: {
        backgroundColor: '#343a40',
        padding: '15px 0',
        color: 'white'
    },
    container: {
        maxWidth: '1200px',
        margin: '0 auto',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '0 20px'
    },
    brand: {
        color: 'white',
        fontSize: '24px',
        fontWeight: 'bold',
        textDecoration: 'none'
    },
    navLinks: {
        display: 'flex',
        gap: '20px'
    },
    navLink: {
        color: 'white',
        textDecoration: 'none',
        fontSize: '16px'
    }
};

export default Header;