import React, { useState, useEffect } from 'react';
import { postService } from '../services/api';
import { Card, Button, Row, Col, Container, Spinner, Alert } from 'react-bootstrap';
import { Link } from 'react-router-dom';

function PostList() {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchPosts();
    }, []);

    const fetchPosts = async () => {
        try {
            setLoading(true);
            const response = await postService.getAllPosts();
            setPosts(response.data);
            setError(null);
        } catch (error) {
            console.error('Error fetching posts:', error);
            setError('Failed to load posts. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this post?')) {
            try {
                await postService.deletePost(id);
                fetchPosts(); // Refresh list
            } catch (error) {
                console.error('Error deleting post:', error);
                alert('Failed to delete post');
            }
        }
    };

    if (loading) {
        return (
            <Container className="text-center my-5">
                <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
                </Spinner>
            </Container>
        );
    }

    if (error) {
        return (
            <Container className="my-5">
                <Alert variant="danger">{error}</Alert>
            </Container>
        );
    }

    return (
        <Container>
            <div className="d-flex justify-content-between align-items-center mb-4">
                <h2>Blog Posts</h2>
                <Link to="/create" className="btn btn-primary">
                    + Create New Post
                </Link>
            </div>
            
            {posts.length === 0 ? (
                <Alert variant="info">
                    No posts found. Create your first post!
                </Alert>
            ) : (
                <Row>
                    {posts.map(post => (
                        <Col md={4} key={post.id} className="mb-4">
                            <Card className="h-100">
                                {post.featured_image && (
                                    <Card.Img 
                                        variant="top" 
                                        src={post.featured_image} 
                                        style={{ height: '200px', objectFit: 'cover' }}
                                    />
                                )}
                                <Card.Body>
                                    <Card.Title>{post.title}</Card.Title>
                                    <Card.Subtitle className="mb-2 text-muted">
                                        By {post.author} | {post.category}
                                    </Card.Subtitle>
                                    <Card.Text>
                                        {post.excerpt || post.content.substring(0, 100)}...
                                    </Card.Text>
                                    <div className="mt-auto">
                                        <Card.Text>
                                            <small className="text-muted">
                                                Status: <span className={`badge bg-${post.status === 'Published' ? 'success' : 'warning'}`}>
                                                    {post.status}
                                                </span>
                                            </small>
                                        </Card.Text>
                                        <div className="d-flex justify-content-between">
                                            <Link 
                                                to={`/post/${post.id}`} 
                                                className="btn btn-sm btn-info"
                                            >
                                                View
                                            </Link>
                                            <Link 
                                                to={`/edit/${post.id}`} 
                                                className="btn btn-sm btn-warning"
                                            >
                                                Edit
                                            </Link>
                                            <Button 
                                                variant="danger" 
                                                size="sm"
                                                onClick={() => handleDelete(post.id)}
                                            >
                                                Delete
                                            </Button>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                    ))}
                </Row>
            )}
        </Container>
    );
}

export default PostList;